export { default } from '../page';


